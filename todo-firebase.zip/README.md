A todo app to demonstrate the use of react and firebase authentication and database

To learn how to create this project from scratch, follow these tutorials:

- [Part one](https://dev.to/aurelkurtula/creating-an-app-with-react-and-firebase---part-one-814) - related [branch: part-one](https://github.com/aurelkurtula/todo-app-with-react-and-firebase/tree/part-one) 
- [Part two](https://dev.to/aurelkurtula/creating-an-app-with-react-and-firebase---part-two-5hmc) - related [branch: part-two](https://github.com/aurelkurtula/todo-app-with-react-and-firebase/tree/part-two)
- [Part three](https://dev.to/aurelkurtula/creating-an-app-with-react-and-firebase---part-three-2c03) - related [branch: part-three](https://github.com/aurelkurtula/todo-app-with-react-and-firebase/tree/part-three)
