import firebase from 'firebase';
const config = {
    apiKey: "AIzaSyDI_giIg0_AbOKraMBHe8yhhdmlB0PstVQ",
    authDomain: "todo-10587.firebaseapp.com",
    databaseURL: "https://todo-10587.firebaseio.com",
    projectId: "todo-10587",
    storageBucket: "todo-10587.appspot.com",
    messagingSenderId: "389364992677"
};
const fire = firebase.initializeApp(config)
const facebookProvider = new firebase.auth.FacebookAuthProvider();

export { fire, facebookProvider }


